/**
 * Module for connect filters
 */
(function() {
    'use strict';
    angular
        .module('filters.module', [
            'filter.auditDate',
            'filter.kriterienTime'

        ]);
})();

