/**
 * Module for connect services
 */
(function () {
  'use strict';
  angular
    .module('services.module', [
      'model.user',
      'model.audit'
      // 'model.comments',
      // 'model.news',
      // 'model.newsDetails',
      // 'model.offerList'
    ])
})();

